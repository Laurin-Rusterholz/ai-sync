# AI Management Pro — Netlify Sync Backend

## Deploy in 5 Minuten

### Schritt 1: GitHub Repo erstellen
1. Geh zu https://github.com/new
2. Name: `ai-mgmt-sync` (oder beliebig)
3. **Public** oder Private — beides geht
4. Klick "Create repository"

### Schritt 2: Dateien hochladen
1. Klick "uploading an existing file"
2. Zieh den ganzen Inhalt dieses Ordners rein:
   - `package.json`
   - `netlify.toml`
   - `netlify/functions/blob-get.mjs`
   - `netlify/functions/blob-put.mjs`
   - `public/index.html`
3. Klick "Commit changes"

### Schritt 3: Netlify verbinden
1. Geh zu https://app.netlify.com
2. "Add new site" → "Import an existing project"
3. Wähl GitHub → dein Repo
4. Build settings leer lassen (defaults passen)
5. Klick "Deploy"

### Schritt 4: (Optional) Auth-Token setzen
1. In Netlify: Site settings → Environment variables
2. Variable hinzufügen:
   - Key: `SYNC_AUTH_TOKEN`
   - Value: Ein beliebiges Passwort (z.B. `mein-geheimes-token-2026`)
3. Redeploy auslösen (Deploys → Trigger deploy)

### Schritt 5: App konfigurieren
In deiner App unter Einstellungen → Storage:

- **Blob Key**: `app-data.json` (Standard, muss nicht geändert werden)
- **GET URL**: `https://DEINE-SITE.netlify.app/.netlify/functions/blob-get?key={key}`
- **PUT URL**: `https://DEINE-SITE.netlify.app/.netlify/functions/blob-put?key={key}`
- **Auth Token**: Dein Token von Schritt 4 (oder leer lassen wenn kein Token gesetzt)

Ersetze `DEINE-SITE` mit dem tatsächlichen Netlify-Subdomain-Namen.

## Fertig!

Jetzt kannst du ☁️ drücken zum Hochladen und 📥 zum Herunterladen auf einem anderen Gerät.
