import { getStore } from "@netlify/blobs";

export default async (req, context) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }

  if (req.method !== "PUT" && req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }

  const url = new URL(req.url);
  const key = url.searchParams.get("key");

  if (!key) {
    return Response.json({ error: "Missing key parameter" }, { status: 400 });
  }

  // Optional auth check
  const expectedToken = Netlify.env.get("SYNC_AUTH_TOKEN");
  if (expectedToken) {
    const provided = req.headers.get("Authorization") || "";
    if (provided !== expectedToken && provided !== `Bearer ${expectedToken}`) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  try {
    const body = await req.text();
    
    // Validate JSON
    try {
      JSON.parse(body);
    } catch {
      return Response.json({ error: "Invalid JSON body" }, { status: 400 });
    }

    const store = getStore("app-sync");

    // Optional ETag conflict check
    const ifMatch = req.headers.get("If-Match");
    if (ifMatch) {
      try {
        const existing = await store.getWithMetadata(key, { type: "text" });
        if (existing.data !== null && existing.etag && existing.etag !== ifMatch) {
          return Response.json({ error: "ETag conflict" }, { status: 412 });
        }
      } catch {
        // No existing data = no conflict
      }
    }

    await store.set(key, body);

    // Read back to get the new ETag
    const saved = await store.getWithMetadata(key, { type: "text" });
    const newEtag = saved.etag || `"${Date.now()}"`;

    return Response.json({ ok: true, key, etag: newEtag }, {
      status: 200,
      headers: {
        "ETag": newEtag,
      },
    });
  } catch (e) {
    console.error("blob-put error:", e);
    return Response.json({ error: e.message }, { status: 500 });
  }
};

export const config = {
  path: "/.netlify/functions/blob-put",
};
