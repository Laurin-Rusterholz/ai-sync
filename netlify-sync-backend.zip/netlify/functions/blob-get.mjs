import { getStore } from "@netlify/blobs";

export default async (req, context) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }

  const url = new URL(req.url);
  const key = url.searchParams.get("key");

  if (!key) {
    return Response.json({ error: "Missing key parameter" }, { status: 400 });
  }

  // Optional auth check
  const expectedToken = Netlify.env.get("SYNC_AUTH_TOKEN");
  if (expectedToken) {
    const provided = req.headers.get("Authorization") || "";
    if (provided !== expectedToken && provided !== `Bearer ${expectedToken}`) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  try {
    const store = getStore("app-sync");
    const { data, etag, metadata } = await store.getWithMetadata(key, { type: "text" });

    if (data === null) {
      return Response.json({ error: "Not found" }, { status: 404 });
    }

    return new Response(data, {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "ETag": etag || `"${Date.now()}"`,
      },
    });
  } catch (e) {
    console.error("blob-get error:", e);
    return Response.json({ error: e.message }, { status: 500 });
  }
};

export const config = {
  path: "/.netlify/functions/blob-get",
};
